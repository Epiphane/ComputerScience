//
//  skybox.h
//  FinalProject
//
//  Created by Thomas Steinke on 3/17/15.
//  Copyright (c) 2015 Thomas Steinke. All rights reserved.
//

#ifndef __FinalProject__skybox__
#define __FinalProject__skybox__

#include "entity.h"

class Skybox : public Entity {
public:
    Skybox();
};

#endif /* defined(__FinalProject__skybox__) */
