//
//  ground.h
//  FinalProject
//
//  Created by Thomas Steinke on 3/15/15.
//  Copyright (c) 2015 Thomas Steinke. All rights reserved.
//

#ifndef __FinalProject__ground__
#define __FinalProject__ground__

#include "entity.h"

class Ground : public Entity {
public:
    Ground();
};

#endif /* defined(__FinalProject__ground__) */
