#ifndef GLINCLUDES_H
#define GLINCLUDES_H

#include <GL/glew.h>

#define GLFW_INCLUDE_NONE
#include <GLFW/glfw3.h>

#endif
