# CageTheObject

To run CageTheObject, type ```make``` in the terminal.
Output: (executable) cagethe

Then, run ```cagethe {input.obj}```. The program will
ask for a window size and color shading scheme.

###NOTE: Recommended window size is 640x480, for optimal
results.